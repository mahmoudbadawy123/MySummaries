<p>
	<strong>Linear</strong><br>
	<a data-easing="linear" href="#bazinga">Linear (no other options)</a><br>
</p>

<p>
	<strong>Ease-In</strong><br>
	<a data-easing="easeInQuad" href="#bazinga">Quad</a><br>
	<a data-easing="easeInCubic" href="#bazinga">Cubic</a><br>
	<a data-easing="easeInQuart" href="#bazinga">Quart</a><br>
	<a data-easing="easeInQuint" href="#bazinga">Quint</a>
</p>

<p>
	<strong>Ease-In-Out</strong><br>
	<a data-easing="easeInOutQuad" href="#bazinga">Quad</a><br>
	<a data-easing="easeInOutCubic" href="#bazinga">Cubic</a><br>
	<a data-easing="easeInOutQuart" href="#bazinga">Quart</a><br>
	<a data-easing="easeInOutQuint" href="#bazinga">Quint</a>
</p>

<p>
	<strong>Ease-Out</strong><br>
	<a data-easing="easeOutQuad" href="#bazinga">Quad</a><br>
	<a data-easing="easeOutCubic" href="#bazinga">Cubic</a><br>
	<a data-easing="easeOutQuart" href="#bazinga">Quart</a><br>
	<a data-easing="easeOutQuint" href="#bazinga">Quint</a>
</p>

<p>
	.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>
	.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>
	.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.
</p>

<p>
	<strong>Non-ASCII Characters</strong><br>
	<a href="#中文">中文</a>
</p>

<p>
	.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>
	.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>
	.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.
</p>

<p id="中文">中文</p>

<p id="bazinga"><a href="#1@#%^-bottom">Bazinga!</a></p>

<p>
	.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>
	.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>
	.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.
</p>

<p id="1@#%^-bottom"><a href="#top">Back to the top</a></p>